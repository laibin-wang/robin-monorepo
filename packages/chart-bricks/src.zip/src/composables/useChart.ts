import type { EChartsOption, ResizeOpts } from 'echarts/types/dist/shared'

import {
	inject,
	onMounted,
	onUnmounted,
	provide,
	ref,
	shallowRef,
	useTemplateRef,
	type InjectionKey,
} from 'vue'

import type { ChartContext, UpdateOptions, UseChartOptions, UseChartReturn } from '../types'

import { Chart } from '../core/Chart'
import { ChartManager } from '../core/ChartManager'
import { createModuleCollector, ModuleCollectorKey } from './useModuleCollector'

export const ChartKey: InjectionKey<Partial<ChartContext>> = Symbol('ChartContext')

export function useChart(options: UseChartOptions = {}): UseChartReturn {
	const {
		config = {},
		initialModules = [],
		id = Math.random().toString(36).slice(2),
		onReady,
		onError,
	} = options

	const containerRef = useTemplateRef<HTMLElement | null>('chartBrickRef')
	const chart = shallowRef<Chart | null>(null)
	const isReady = ref(false)
	const isLoading = ref(false)
	const error = ref<Error | null>(null)

	const manager = ChartManager.getInstance()
	const { collector } = createModuleCollector()
	provide(ModuleCollectorKey, collector)

	onMounted(async () => {
		if (!containerRef.value) {
			error.value = new Error('Container element not found')
			onError?.(error.value)
			return
		}

		try {
			isLoading.value = true
			const instance = new Chart(containerRef.value, config)
			const declaredModules = collector.getAll()
			const allModules = [...new Set([...initialModules, ...declaredModules])]
			instance.require(...allModules)

			await instance.init()

			chart.value = instance
			manager.register(id, instance)
			isReady.value = true
			isLoading.value = false

			provide(ChartKey, instance.getContext())
			onReady?.(instance)
		} catch (err) {
			isLoading.value = false
			error.value = err instanceof Error ? err : new Error(String(err))
			onError?.(error.value)
		}
	})

	onUnmounted(() => {
		manager.dispose(id)
		chart.value?.dispose()
		isReady.value = false
	})

	return {
		chartRef: containerRef,
		chart,
		isReady,
		isLoading,
		error,
		setOption: (opt: EChartsOption, opts: UpdateOptions = {}) => chart.value?.setOption(opt, opts),
		resize: (opts: ResizeOpts) => chart.value?.resize(opts),
		dispatchAction: payload => chart.value?.dispatchAction(payload),
		on: (event: string, handler: Function) => chart.value?.on(event, handler),
		off: (event: string, handler: Function) => chart.value?.off(event, handler),
		showLoading: opts => chart.value?.showLoading(opts),
		hideLoading: () => chart.value?.hideLoading(),
		clear: () => chart.value?.clear(),
		dispose: () => chart.value?.dispose(),
		getOption: () => chart.value?.getOption(),
	}
}
export function useChartContext(): ChartContext {
	const ctx = inject<ChartContext>(ChartKey)
	if (!ctx) {
		throw new Error('useChartContext must be used inside a Chart component')
	}
	return ctx
}
