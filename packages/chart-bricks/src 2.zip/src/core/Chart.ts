import type { ECBasicOption, ResizeOpts, EChartsType } from 'echarts/types/dist/shared'

import { init, dispose } from 'echarts/core'

import type { ChartConfig, EChartsFullOption, UpdateOptions } from '../types'

import { deepMerge } from '../utils/chartHelpers'
import { registerModules, type ModuleName } from '../utils/register'

export class Chart {
	instance: EChartsType | null = null
	container: HTMLElement
	config: ChartConfig
	private performance = {
		updateCount: 0,
		lastUpdateTime: 0,
		averageUpdateTime: 0,
	}
	private updateQueue: EChartsFullOption[] = []
	private rafId: number | null = null
	private eventHandlers: Map<string, Set<Function>> = new Map()
	private requiredModules: Set<ModuleName> = new Set()
	private isRegistering = false
	private registrationPromise: Promise<void> | null = null
	private pendingEvents: Array<{ type: 'add' | 'remove'; event: string; handler: Function }> = []
	private isProcessingEvents = false

	constructor(container: HTMLElement, config: ChartConfig = {}) {
		this.container = container
		this.config = {
			renderer: 'canvas',
			theme: 'default',
			autoResize: true,
			useDirtyRect: true,
			useCoarsePointer: true,
			pointerSize: 20,
			...config,
		}
	}
	require(...modules: ModuleName[]): this {
		if (this.instance) {
			console.warn('Cannot add modules after chart is initialized')
			return this
		}
		modules.forEach(m => this.requiredModules.add(m))
		return this
	}

	async init(): Promise<void> {
		if (this.instance || this.isRegistering) this.isRegistering = true

		const rendererName = this.config.renderer === 'svg' ? 'svg' : 'canvas'
		this.requiredModules.add(rendererName as ModuleName)

		this.registrationPromise = registerModules([...this.requiredModules])
		console.log('registering modules', this.requiredModules)
		await this.registrationPromise

		this.instance = init(this.container, this.config.theme, {
			renderer: this.config.renderer,
			useDirtyRect: this.config.useDirtyRect,
			useCoarsePointer: this.config.useCoarsePointer,
			pointerSize: this.config.pointerSize,
			locale: this.config.locale,
		})

		this.isRegistering = false
	}

	async ready(): Promise<void> {
		if (this.instance) return
		if (this.registrationPromise) {
			await this.registrationPromise
		}
	}

	setOption(option: EChartsFullOption, opts: UpdateOptions = {}): void {
		this.updateQueue.push(option)

		if (this.rafId === null) {
			this.rafId = requestAnimationFrame(() => this.flushUpdate(opts))
		}
	}

	private flushUpdate(opts: UpdateOptions): void {
		const startTime = performance.now()
		if (!this.instance || this.updateQueue.length === 0) {
			this.rafId = null
			return
		}

		const merged: EChartsFullOption = {}
		for (const option of this.updateQueue) {
			deepMerge(merged, option)
		}
		console.log('merged option', merged)
		this.instance.setOption(merged, {
			notMerge: opts.notMerge ?? false,
			lazyUpdate: opts.lazyUpdate ?? false,
			silent: opts.silent ?? false,
		})

		this.updateQueue.length = 0
		this.rafId = null
		const duration = performance.now() - startTime
		this.updatePerformanceMetrics(duration)
	}

	resize(opts?: ResizeOpts): void {
		this.instance?.resize(opts)
	}

	on(event: string, handler: Function): void {
		this.pendingEvents.push({ type: 'add', event, handler })
		this.scheduleEventProcessing()
	}
	private scheduleEventProcessing(): void {
		if (this.isProcessingEvents || !this.instance) return

		this.isProcessingEvents = true
		queueMicrotask(() => {
			const events = [...this.pendingEvents]
			this.pendingEvents.length = 0

			for (const { type, event, handler } of events) {
				if (type === 'add') {
					if (!this.eventHandlers.has(event)) {
						this.eventHandlers.set(event, new Set())
					}
					this.eventHandlers.get(event)!.add(handler)
					this.instance!.on(event, handler as any)
				} else {
					this.eventHandlers.get(event)?.delete(handler)
					this.instance!.off(event, handler as any)
				}
			}

			this.isProcessingEvents = false
		})
	}
	private updatePerformanceMetrics(duration: number): void {
		this.performance.updateCount++
		this.performance.averageUpdateTime =
			(this.performance.averageUpdateTime * (this.performance.updateCount - 1) + duration) /
			this.performance.updateCount

		if (this.performance.averageUpdateTime > 16) {
			console.warn(
				'Chart updates are taking too long:',
				this.performance.averageUpdateTime.toFixed(2) + 'ms',
			)
		}
	}

	off(event: string, handler: Function): void {
		this.pendingEvents.push({ type: 'remove', event, handler })
		this.scheduleEventProcessing()
	}

	dispatchAction(payload: any): void {
		this.instance?.dispatchAction(payload)
	}

	showLoading(opts?: any): void {
		this.instance?.showLoading(opts)
	}

	hideLoading(): void {
		this.instance?.hideLoading()
	}

	clear(): void {
		this.instance?.clear()
	}
	getOption(): ECBasicOption | undefined {
		return this.instance?.getOption()
	}

	dispose(): void {
		if (this.rafId) {
			cancelAnimationFrame(this.rafId)
			this.rafId = null
		}

		this.eventHandlers.forEach((handlers, event) => {
			handlers.forEach(handler => this.instance?.off(event, handler as any))
		})
		this.eventHandlers.clear()

		if (this.instance) {
			dispose(this.instance)
		}
	}
}
